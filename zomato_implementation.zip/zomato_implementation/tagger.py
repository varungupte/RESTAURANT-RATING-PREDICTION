'''
Created on Thu Nov 2 2017
@author: vipulkhatana
'''
import subprocess

def getTag(data):
	f = open('tagdata.txt','w')
	# print("tagger ",data)
	f.write(data)
	f.close()
	proc = subprocess.run(['sh','tag-request.sh','./cdacm-model/hin-accurate.tagger','tagdata.txt'], stdout=subprocess.PIPE)
	# (out, err) = proc.communicate()
	# print(" output is:-",proc.stdout.decode('utf-8'))
	return proc.stdout.decode('utf-8')


	 # ./cdacm-model/hin-accurate.tagger -tokenized 'false' -textFile tagdata.txt